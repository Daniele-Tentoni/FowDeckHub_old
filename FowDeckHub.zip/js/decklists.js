function create_deck() {
    
}