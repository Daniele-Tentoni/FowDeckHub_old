<div class="input-group">
	<span class="input-group-addon"><span class="fa fa-pencil"></span></span>
	<select class="form-control select" id="visibility" onchange="visibility_change(event);" z-index="1">
		<option value="0">Not visible</option>
		<option value="1">Visible</option>
	</select>
</div>